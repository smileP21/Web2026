# Petr Šilhavý Reality - Web Application

Moderní webová aplikace pro realitní agenturu Petra Šilhavého v Brně, vytvořená s Next.js 14, Supabase, Tailwind CSS a TypeScript.

## Technologie

- **Frontend**: Next.js 14 (React 18)
- **Styling**: Tailwind CSS
- **Backend**: Supabase (PostgreSQL)
- **Autentizace**: Supabase Auth
- **Datové dotazy**: React Query
- **Forms**: React Hook Form + Zod
- **Maps**: Leaflet + React Leaflet
- **Animace**: Framer Motion
- **Email**: Brevo API

## Instalace

1. Klonujte repository
```bash
git clone <repository-url>
cd petr-silhavy-reality
```

2. Nainstalujte závislosti
```bash
npm install
```

3. Vytvořte `.env.local` soubor
```bash
cp .env.local.example .env.local
```

4. Vyplňte proměnné prostředí
```
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
BREVO_API_KEY=your_brevo_api_key
```

5. Spusťte dev server
```bash
npm run dev
```

Server běží na `http://localhost:3000`

## Struktura projektu

```
src/
├── app/              # Next.js app router
│   ├── (public)/     # Veřejné stránky
│   ├── (admin)/      # Admin panel
│   ├── api/          # API routes
│   ├── layout.tsx    # Root layout
│   └── globals.css   # Global styles
├── components/       # React komponenty
│   ├── admin/        # Admin komponenty
│   ├── forms/        # Formulářové komponenty
│   ├── calculators/  # Kalkulačky
│   └── ...
├── lib/             # Utility funkce a hooks
│   ├── supabase/    # Supabase klienti
│   ├── hooks/       # React hooks
│   ├── types.ts     # TypeScript typy
│   └── utils.ts     # Utility funkce
└── middleware.ts    # Next.js middleware
```

## Veřejné stránky

- `/` - Homepage
- `/nemovitosti` - Výpis nemovitostí
- `/nemovitosti/[id]` - Detail nemovitosti
- `/investice` - Investiční stránka
- `/o-mne` - O autorovi
- `/kontakt` - Kontaktní formulář

## Admin panel

- `/admin/login` - Přihlášení
- `/admin/dashboard` - Dashboard
- `/admin/properties` - Správa nemovitostí
- `/admin/leads` - Správa poptávek
- `/admin/blog` - Správa blogu
- `/admin/settings` - Nastavení

## Databázové tabulky

- `properties` - Nemovitosti
- `leads` - Poptávky/kontakty
- `blog_posts` - Blogové články
- `settings` - Globální nastavení

## Deploy

### Vercel (doporučeno)

```bash
vercel
```

### Jiné hosting služby

Postačuje standardní Next.js build a start procesy:

```bash
npm run build
npm run start
```

## Přispívání

Buďte prosím opatrní při úpravách a testujte veškeré změny.

## Licence

Soukromý projekt.
