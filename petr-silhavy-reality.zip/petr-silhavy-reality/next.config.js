/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['kbznxwakchdzfhoutpym.supabase.co'], // pro obrázky ze Supabase storage
  },
}

module.exports = nextConfig
