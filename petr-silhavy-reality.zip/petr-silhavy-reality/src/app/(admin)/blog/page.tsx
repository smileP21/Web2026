import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'
import { Plus } from 'lucide-react'
import { formatDate } from '@/lib/utils'

export default async function AdminBlog() {
  const supabase = await createClient()

  const { data: posts } = await supabase
    .from('blog_posts')
    .select('*')
    .order('created_at', { ascending: false })

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Blog</h1>
        <Link
          href="/admin/blog/new"
          className="flex items-center gap-2 bg-primary-600 text-white px-4 py-2 rounded-xl hover:bg-primary-700"
        >
          <Plus className="w-5 h-5" /> Nový článek
        </Link>
      </div>

      <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50 border-b">
            <tr>
              <th className="p-4 text-left">Název</th>
              <th className="p-4 text-left">Kategorie</th>
              <th className="p-4 text-left">Vytvořeno</th>
              <th className="p-4 text-left">Status</th>
              <th className="p-4 text-left">Akce</th>
            </tr>
          </thead>
          <tbody>
            {posts?.map((post) => (
              <tr key={post.id} className="border-b hover:bg-slate-50">
                <td className="p-4 font-medium">{post.title}</td>
                <td className="p-4">{post.category || '-'}</td>
                <td className="p-4">{formatDate(post.created_at)}</td>
                <td className="p-4">
                  <span
                    className={`px-2 py-1 rounded-full text-sm ${
                      post.published ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                    }`}
                  >
                    {post.published ? 'Publikováno' : 'Skryto'}
                  </span>
                </td>
                <td className="p-4">
                  <Link href={`/admin/blog/${post.id}`} className="text-primary-600 hover:underline">
                    Upravit
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
