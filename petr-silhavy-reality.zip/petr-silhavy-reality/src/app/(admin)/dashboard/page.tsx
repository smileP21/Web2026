import { createClient } from '@/lib/supabase/server'
import { Home, Users, FileText } from 'lucide-react'

export default async function AdminDashboard() {
  const supabase = await createClient()

  const { count: propertiesCount } = await supabase
    .from('properties')
    .select('*', { count: 'exact', head: true })

  const { count: leadsCount } = await supabase
    .from('leads')
    .select('*', { count: 'exact', head: true })

  const { count: blogCount } = await supabase
    .from('blog_posts')
    .select('*', { count: 'exact', head: true })

  return (
    <div>
      <h1 className="text-3xl font-bold mb-8">Dashboard</h1>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <Home className="w-8 h-8 text-primary-600" />
            <span className="text-2xl font-bold">{propertiesCount || 0}</span>
          </div>
          <p className="text-slate-600">Nemovitostí</p>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <Users className="w-8 h-8 text-primary-600" />
            <span className="text-2xl font-bold">{leadsCount || 0}</span>
          </div>
          <p className="text-slate-600">Poptávek</p>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <FileText className="w-8 h-8 text-primary-600" />
            <span className="text-2xl font-bold">{blogCount || 0}</span>
          </div>
          <p className="text-slate-600">Blogových článků</p>
        </div>
      </div>
    </div>
  )
}
