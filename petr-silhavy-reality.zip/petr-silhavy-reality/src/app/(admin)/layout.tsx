'use client'

import { useAuth } from '@/lib/hooks/useAuth'
import { useRouter } from 'next/navigation'
import { useEffect } from 'react'
import Link from 'next/link'
import { LayoutDashboard, Home, Users, FileText, Settings, LogOut } from 'lucide-react'

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const { user, isLoading, signOut } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isLoading && !user) {
      router.push('/admin/login')
    }
  }, [user, isLoading, router])

  if (isLoading) return <div className="min-h-screen flex items-center justify-center">Načítání...</div>

  if (!user) return null

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-slate-200 p-6">
        <div className="mb-8">
          <h2 className="text-xl font-bold">Admin</h2>
          <p className="text-sm text-slate-500">{user.email}</p>
        </div>

        <nav className="space-y-2">
          <Link href="/admin/dashboard" className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-100 transition-colors">
            <LayoutDashboard className="w-5 h-5" /> Dashboard
          </Link>

          <Link href="/admin/properties" className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-100 transition-colors">
            <Home className="w-5 h-5" /> Nemovitosti
          </Link>

          <Link href="/admin/leads" className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-100 transition-colors">
            <Users className="w-5 h-5" /> Poptávky
          </Link>

          <Link href="/admin/blog" className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-100 transition-colors">
            <FileText className="w-5 h-5" /> Blog
          </Link>

          <Link href="/admin/settings" className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-100 transition-colors">
            <Settings className="w-5 h-5" /> Nastavení
          </Link>

          <button
            onClick={() => signOut()}
            className="flex items-center gap-3 p-3 rounded-xl hover:bg-red-50 text-red-600 w-full text-left"
          >
            <LogOut className="w-5 h-5" /> Odhlásit
          </button>
        </nav>
      </aside>

      <main className="flex-1 p-8">{children}</main>
    </div>
  )
}
