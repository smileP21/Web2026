import { createClient } from '@/lib/supabase/server'
import { formatDate } from '@/lib/utils'
import LeadActions from '@/components/admin/LeadActions'

export default async function AdminLeads() {
  const supabase = await createClient()

  const { data: leads } = await supabase
    .from('leads')
    .select('*')
    .order('created_at', { ascending: false })

  return (
    <div>
      <h1 className="text-3xl font-bold mb-8">Poptávky</h1>

      <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50 border-b">
            <tr>
              <th className="p-4 text-left">Datum</th>
              <th className="p-4 text-left">Jméno</th>
              <th className="p-4 text-left">Email</th>
              <th className="p-4 text-left">Telefon</th>
              <th className="p-4 text-left">Typ</th>
              <th className="p-4 text-left">Status</th>
              <th className="p-4 text-left">Akce</th>
            </tr>
          </thead>
          <tbody>
            {leads?.map((lead) => (
              <tr key={lead.id} className="border-b hover:bg-slate-50">
                <td className="p-4">{formatDate(lead.created_at)}</td>
                <td className="p-4 font-medium">{lead.name}</td>
                <td className="p-4">{lead.email}</td>
                <td className="p-4">{lead.phone}</td>
                <td className="p-4 capitalize">{lead.type}</td>
                <td className="p-4">
                  <LeadActions leadId={lead.id} currentStatus={lead.status} />
                </td>
                <td className="p-4">
                  <button className="text-red-600 hover:text-red-800">Smazat</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
