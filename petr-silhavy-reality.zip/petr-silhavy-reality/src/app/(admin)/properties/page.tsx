import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'
import { Plus } from 'lucide-react'

export default async function AdminProperties() {
  const supabase = await createClient()

  const { data: properties } = await supabase
    .from('properties')
    .select('*')
    .order('created_at', { ascending: false })

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Nemovitosti</h1>
        <Link
          href="/admin/properties/new"
          className="flex items-center gap-2 bg-primary-600 text-white px-4 py-2 rounded-xl hover:bg-primary-700"
        >
          <Plus className="w-5 h-5" /> Nová nemovitost
        </Link>
      </div>

      <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50 border-b">
            <tr>
              <th className="p-4 text-left">Název</th>
              <th className="p-4 text-left">Lokalita</th>
              <th className="p-4 text-left">Cena</th>
              <th className="p-4 text-left">Typ</th>
              <th className="p-4 text-left">Status</th>
              <th className="p-4 text-left">Akce</th>
            </tr>
          </thead>
          <tbody>
            {properties?.map((property) => (
              <tr key={property.id} className="border-b hover:bg-slate-50">
                <td className="p-4 font-medium">{property.title}</td>
                <td className="p-4">{property.location}</td>
                <td className="p-4">{property.price?.toLocaleString('cs-CZ')} Kč</td>
                <td className="p-4">{property.type}</td>
                <td className="p-4">
                  <span
                    className={`px-2 py-1 rounded-full text-sm ${
                      property.published ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                    }`}
                  >
                    {property.published ? 'Publikováno' : 'Skryto'}
                  </span>
                </td>
                <td className="p-4">
                  <Link href={`/admin/properties/${property.id}`} className="text-primary-600 hover:underline">
                    Upravit
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
