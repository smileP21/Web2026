import { createClient } from '@/lib/supabase/server'

export default async function AdminSettings() {
  const supabase = await createClient()

  const { data: settings } = await supabase.from('settings').select('*')

  const settingsMap = Object.fromEntries(settings?.map((s) => [s.key, s.value]) || [])

  return (
    <div>
      <h1 className="text-3xl font-bold mb-8">Nastavení</h1>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <h2 className="text-xl font-bold mb-6">Základní informace</h2>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Název firmy</label>
              <input
                type="text"
                defaultValue={settingsMap.company_name || 'Petr Šilhavý Reality'}
                className="w-full p-3 border rounded-xl"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Email</label>
              <input
                type="email"
                defaultValue={settingsMap.email || 'silhavypetr.reality@gmail.com'}
                className="w-full p-3 border rounded-xl"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Telefon</label>
              <input
                type="tel"
                defaultValue={settingsMap.phone || '+420 777 449 857'}
                className="w-full p-3 border rounded-xl"
              />
            </div>

            <button className="w-full bg-primary-600 text-white py-2 rounded-xl font-medium hover:bg-primary-700">
              Uložit
            </button>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <h2 className="text-xl font-bold mb-6">O mně</h2>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Profil - text</label>
              <textarea
                rows={4}
                defaultValue={settingsMap.about_text || ''}
                className="w-full p-3 border rounded-xl"
              />
            </div>

            <button className="w-full bg-primary-600 text-white py-2 rounded-xl font-medium hover:bg-primary-700">
              Uložit
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
