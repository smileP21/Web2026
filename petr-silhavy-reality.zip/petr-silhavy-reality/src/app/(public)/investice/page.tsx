'use client'

import InvestmentQuiz from '@/components/forms/InvestmentQuiz'
import MortgageCalculator from '@/components/calculators/MortgageCalculator'
import RoiCalculator from '@/components/calculators/RoiCalculator'

export default function InvestmentsPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-4">Investice a hypotéky</h1>
      <p className="text-lg text-slate-600 mb-12">
        Díky spolupráci s finanční skupinou Ofis a.s. nabízíme komplexní řešení pro vaše finance.
      </p>

      <div className="grid lg:grid-cols-2 gap-12 mb-16">
        <div className="bg-white rounded-3xl p-8 shadow-sm">
          <h2 className="text-2xl font-bold mb-6">Hypoteční kalkulačka</h2>
          <MortgageCalculator />
        </div>

        <div className="bg-white rounded-3xl p-8 shadow-sm">
          <h2 className="text-2xl font-bold mb-6">ROI kalkulačka</h2>
          <RoiCalculator />
        </div>
      </div>

      <div className="bg-primary-50 rounded-3xl p-8 md:p-12">
        <h2 className="text-3xl font-bold mb-8">Najděte svou investici</h2>
        <InvestmentQuiz />
      </div>
    </div>
  )
}
