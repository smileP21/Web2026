'use client'

import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { MapPin, Phone, Mail, Send, Loader2 } from 'lucide-react'
import dynamic from 'next/dynamic'

const Map = dynamic(() => import('@/components/ContactMap'), { ssr: false })

const schema = z.object({
  name: z.string().min(1, 'Jméno je povinné'),
  email: z.string().email('Neplatný email'),
  phone: z.string().min(9, 'Telefon je povinný'),
  message: z.string().min(1, 'Zpráva je povinná'),
})

type FormData = z.infer<typeof schema>

export default function ContactPage() {
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')

  const supabase = createClient()

  const { register, handleSubmit, formState: { errors }, reset } = useForm<FormData>({
    resolver: zodResolver(schema),
  })

  const onSubmit = async (data: FormData) => {
    setStatus('loading')

    const { error } = await supabase.from('leads').insert([{
      type: 'kontakt',
      ...data,
      status: 'Nová',
    }])

    if (error) {
      setStatus('error')
    } else {
      setStatus('success')
      reset()
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-12">Kontakt</h1>

      <div className="grid lg:grid-cols-2 gap-12">
        <div>
          <div className="bg-white rounded-3xl p-8 shadow-sm mb-8">
            <h2 className="text-2xl font-bold mb-6">Kontaktní údaje</h2>

            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-primary-600" />
                <a href="tel:+420777449857" className="hover:text-primary-600">
                  +420 777 449 857
                </a>
              </div>

              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-primary-600" />
                <a href="mailto:Silhavypetr.reality@gmail.com" className="hover:text-primary-600">
                  Silhavypetr.reality@gmail.com
                </a>
              </div>

              <div className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-primary-600" />
                <span>Brno, Česká republika</span>
              </div>
            </div>
          </div>

          <div className="bg-primary-50 rounded-3xl p-8">
            <h2 className="text-xl font-bold mb-4">Finanční skupina Ofis a.s.</h2>
            <p className="text-slate-700 mb-6">
              Zajišťujeme nejen prodej a pronájem, ale také kompletní finanční servis, hypotéky a investiční příležitosti.
            </p>
            <a href="/investice" className="text-primary-600 font-medium hover:underline">
              Více o investicích →
            </a>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-8 shadow-sm">
          <h2 className="text-2xl font-bold mb-6">Napište mi</h2>

          {status === 'success' ? (
            <div className="bg-green-50 p-6 rounded-xl text-center">
              <p className="text-green-800">Děkuji za zprávu! Ozvu se co nejdříve.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div>
                <input
                  {...register('name')}
                  placeholder="Jméno a příjmení"
                  className="w-full p-3 border rounded-xl"
                />
                {errors.name && <p className="text-red-600 text-sm mt-1">{errors.name.message}</p>}
              </div>

              <div>
                <input
                  {...register('email')}
                  type="email"
                  placeholder="Email"
                  className="w-full p-3 border rounded-xl"
                />
                {errors.email && <p className="text-red-600 text-sm mt-1">{errors.email.message}</p>}
              </div>

              <div>
                <input
                  {...register('phone')}
                  placeholder="Telefon"
                  className="w-full p-3 border rounded-xl"
                />
                {errors.phone && <p className="text-red-600 text-sm mt-1">{errors.phone.message}</p>}
              </div>

              <div>
                <textarea
                  {...register('message')}
                  rows={4}
                  placeholder="Vaše zpráva"
                  className="w-full p-3 border rounded-xl"
                />
                {errors.message && <p className="text-red-600 text-sm mt-1">{errors.message.message}</p>}
              </div>

              <button
                type="submit"
                disabled={status === 'loading'}
                className="w-full bg-primary-600 text-white py-3 rounded-xl font-medium hover:bg-primary-700 transition-colors disabled:opacity-50 flex items-center justify-center"
              >
                {status === 'loading' ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <Send className="w-5 h-5 mr-2" /> Odeslat zprávu
                  </>
                )}
              </button>
            </form>
          )}
        </div>
      </div>

      <div className="mt-12 h-[400px] rounded-3xl overflow-hidden">
        <Map />
      </div>
    </div>
  )
}
