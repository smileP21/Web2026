import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import ExitIntentPopup from '@/components/ExitIntentPopup'
import StickyContact from '@/components/StickyContact'

export default function PublicLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <>
      <Navbar />
      <main className="min-h-screen">{children}</main>
      <Footer />
      <ExitIntentPopup />
      <StickyContact />
    </>
  )
}
