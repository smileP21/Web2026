import { notFound } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import PropertyCard from '@/components/PropertyCard'
import { MapPin } from 'lucide-react'

export default async function LocationPage({ params }: { params: { cast: string } }) {
  const locationName = params.cast.replace(/-/g, ' ')

  const supabase = await createClient()

  const { data: properties } = await supabase
    .from('properties')
    .select('*')
    .eq('published', true)
    .eq('status', 'aktivní')
    .ilike('location', `%${locationName}%`)
    .order('created_at', { ascending: false })

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="flex items-center gap-2 text-slate-600 mb-4">
        <MapPin className="w-5 h-5" />
        <span>Lokalita</span>
      </div>
      <h1 className="text-4xl font-bold mb-6 capitalize">{locationName}</h1>

      {properties && properties.length > 0 ? (
        <>
          <p className="text-lg text-slate-600 mb-12">
            Nabízíme {properties.length} nemovitostí v lokalitě {locationName}.
          </p>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {properties.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        </>
      ) : (
        <div className="bg-slate-50 rounded-3xl p-12 text-center">
          <p className="text-xl text-slate-600 mb-4">
            Aktuálně zde nemám žádnou nemovitost, ale {locationName} je skvělá lokalita.
          </p>
          <p className="text-slate-500">Sledujte mě, novinky přibývají. Nebo mi napište, co hledáte.</p>
        </div>
      )}
    </div>
  )
}
