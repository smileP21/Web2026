import { notFound } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import Image from 'next/image'
import Link from 'next/link'
import { MapPin, Home, Maximize, BedDouble, ExternalLink, ArrowLeft } from 'lucide-react'
import PropertyMap from '@/components/PropertyMap'
import PropertyContactForm from '@/components/forms/PropertyContactForm'
import { formatPrice } from '@/lib/utils'

export default async function PropertyDetailPage({ params }: { params: { id: string } }) {
  const supabase = await createClient()

  const { data: property } = await supabase
    .from('properties')
    .select('*')
    .eq('id', params.id)
    .single()

  if (!property) {
    notFound()
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <Link href="/nemovitosti" className="inline-flex items-center text-primary-600 hover:text-primary-700 mb-8">
        <ArrowLeft className="w-4 h-4 mr-2" /> Zpět na nabídku
      </Link>

      <div className="grid lg:grid-cols-2 gap-12">
        {/* Levá strana -- fotky a mapa */}
        <div>
          <div className="relative h-[400px] rounded-3xl overflow-hidden mb-4">
            <Image
              src={property.images?.[0] || 'https://picsum.photos/800/600'}
              alt={property.title}
              fill
              className="object-cover"
              priority
            />
          </div>
          <div className="grid grid-cols-3 gap-2 mb-8">
            {property.images?.slice(1, 4).map((img, idx) => (
              <div key={idx} className="relative h-24 rounded-xl overflow-hidden">
                <Image src={img} alt="" fill className="object-cover" />
              </div>
            ))}
          </div>
          <div className="h-[300px] rounded-2xl overflow-hidden border">
            <PropertyMap properties={[property]} center={[property.latitude || 0, property.longitude || 0]} />
          </div>
        </div>

        {/* Pravá strana -- detaily a formulář */}
        <div>
          <div className="mb-6">
            <div className="inline-block px-3 py-1 bg-primary-100 text-primary-800 rounded-full text-sm font-medium mb-4">
              {property.type}
            </div>
            <h1 className="text-4xl font-bold mb-4">{property.title}</h1>
            <p className="text-3xl font-bold text-primary-600 mb-4">
              {property.price ? formatPrice(property.price) : 'Cena na vyžádání'}
            </p>
            <div className="flex items-center text-slate-600">
              <MapPin className="w-5 h-5 mr-2" /> {property.location}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 mb-8">
            <div className="bg-slate-50 p-4 rounded-2xl text-center">
              <Home className="w-6 h-6 text-primary-600 mx-auto mb-2" />
              <span className="text-sm text-slate-500 block mb-1">Typ</span>
              <span className="font-semibold">{property.type}</span>
            </div>
            <div className="bg-slate-50 p-4 rounded-2xl text-center">
              <Maximize className="w-6 h-6 text-primary-600 mx-auto mb-2" />
              <span className="text-sm text-slate-500 block mb-1">Plocha</span>
              <span className="font-semibold">{property.size_sqm} m²</span>
            </div>
            <div className="bg-slate-50 p-4 rounded-2xl text-center">
              <BedDouble className="w-6 h-6 text-primary-600 mx-auto mb-2" />
              <span className="text-sm text-slate-500 block mb-1">Pokoje</span>
              <span className="font-semibold">{property.bedrooms || '-'}</span>
            </div>
          </div>

          <div className="prose max-w-none mb-8">
            <h3 className="text-xl font-bold mb-4">Popis nemovitosti</h3>
            <p className="whitespace-pre-wrap">{property.description}</p>
          </div>

          {property.external_link && (
            <a
              href={property.external_link}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-slate-900 text-white px-6 py-3 rounded-xl font-medium hover:bg-slate-800 transition-colors mb-8"
            >
              <ExternalLink className="w-5 h-5" /> Zobrazit inzerát (video)
            </a>
          )}

          <div className="bg-primary-50 rounded-3xl p-8">
            <h3 className="text-2xl font-bold mb-4">Máte zájem o prohlídku?</h3>
            <PropertyContactForm propertyId={property.id} />
          </div>
        </div>
      </div>
    </div>
  )
}
