'use client'

import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { createClient } from '@/lib/supabase/client'
import PropertyCard from '@/components/PropertyCard'
import PropertyMap from '@/components/PropertyMap'
import { Search, Grid3x3, Map as MapIcon } from 'lucide-react'
import { cn } from '@/lib/utils'

export default function PropertiesPage() {
  const [view, setView] = useState<'grid' | 'map'>('grid')
  const [search, setSearch] = useState('')
  const [typeFilter, setTypeFilter] = useState('')
  const [priceMin, setPriceMin] = useState('')
  const [priceMax, setPriceMax] = useState('')

  const supabase = createClient()

  const { data: properties } = useQuery({
    queryKey: ['properties', search, typeFilter, priceMin, priceMax],
    queryFn: async () => {
      let query = supabase
        .from('properties')
        .select('*')
        .eq('published', true)
        .eq('status', 'aktivní')
        .order('created_at', { ascending: false })

      if (search) {
        query = query.ilike('location', `%${search}%`)
      }

      if (typeFilter) {
        query = query.eq('type', typeFilter)
      }

      if (priceMin) {
        query = query.gte('price', parseInt(priceMin))
      }

      if (priceMax) {
        query = query.lte('price', parseInt(priceMax))
      }

      const { data } = await query

      return data || []
    },
  })

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8">Nabídka nemovitostí</h1>

      {/* Filtry */}
      <div className="bg-white rounded-2xl p-6 shadow-sm mb-8">
        <div className="grid md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Lokalita"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border rounded-xl"
            />
          </div>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="w-full px-4 py-3 border rounded-xl"
          >
            <option value="">Všechny typy</option>
            <option value="byt">Byt</option>
            <option value="dům">Dům</option>
            <option value="pozemek">Pozemek</option>
            <option value="komerční">Komerční</option>
          </select>
          <input
            type="number"
            placeholder="Min. cena"
            value={priceMin}
            onChange={(e) => setPriceMin(e.target.value)}
            className="w-full px-4 py-3 border rounded-xl"
          />
          <input
            type="number"
            placeholder="Max. cena"
            value={priceMax}
            onChange={(e) => setPriceMax(e.target.value)}
            className="w-full px-4 py-3 border rounded-xl"
          />
        </div>
      </div>

      {/* Přepínač zobrazení */}
      <div className="flex justify-end mb-6">
        <div className="bg-slate-100 p-1 rounded-xl flex">
          <button
            onClick={() => setView('grid')}
            className={cn(
              'px-4 py-2 rounded-lg flex items-center gap-2 transition-colors',
              view === 'grid' ? 'bg-white shadow-sm' : 'text-slate-600'
            )}
          >
            <Grid3x3 className="w-5 h-5" /> Grid
          </button>
          <button
            onClick={() => setView('map')}
            className={cn(
              'px-4 py-2 rounded-lg flex items-center gap-2 transition-colors',
              view === 'map' ? 'bg-white shadow-sm' : 'text-slate-600'
            )}
          >
            <MapIcon className="w-5 h-5" /> Mapa
          </button>
        </div>
      </div>

      {/* Obsah */}
      {view === 'grid' ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {properties?.map((property) => (
            <PropertyCard key={property.id} property={property} />
          ))}
        </div>
      ) : (
        <div className="h-[600px] rounded-2xl overflow-hidden border">
          <PropertyMap properties={properties || []} />
        </div>
      )}
    </div>
  )
}
