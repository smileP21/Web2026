import { createClient } from '@/lib/supabase/server'
import Image from 'next/image'
import { CheckCircle } from 'lucide-react'

export default async function AboutPage() {
  const supabase = await createClient()

  const { data: settings } = await supabase.from('settings').select('*')

  const settingsMap = Object.fromEntries(settings?.map(s => [s.key, s.value]) || [])

  const reasons = settingsMap.reasons ? JSON.parse(settingsMap.reasons) : []

  const profileImage = settingsMap.profile_image || 'https://picsum.photos/seed/profile/400/400'

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-12">O mně</h1>

      <div className="grid md:grid-cols-2 gap-12 items-start mb-16">
        <div className="relative h-[400px] rounded-3xl overflow-hidden">
          <Image src={profileImage} alt="Petr Šilhavý" fill className="object-cover" />
        </div>

        <div>
          <p className="text-lg text-slate-700 mb-6 leading-relaxed">
            {settingsMap.about_text ||
              'Jsem realitní makléř s láskou k Brnu a moderním technologiím. Mým cílem je, aby prodej nebo koupě nemovitosti byly pro vás co nejjednodušší a nejpříjemnější.'}
          </p>

          <div className="space-y-4">
            {reasons.map((reason: any, idx: number) => (
              <div key={idx} className="flex items-start gap-3">
                <CheckCircle className="w-6 h-6 text-primary-600 shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-lg">{reason.title}</h3>
                  <p className="text-slate-600">{reason.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Ukázky práce (placeholder) */}
      <div className="bg-slate-50 rounded-3xl p-12">
        <h2 className="text-2xl font-bold mb-8">Klienti, kterým jsem pomohl</h2>
        <p className="text-slate-500">Brzy zde přibudou reference a úspěšné příběhy.</p>
      </div>
    </div>
  )
}
