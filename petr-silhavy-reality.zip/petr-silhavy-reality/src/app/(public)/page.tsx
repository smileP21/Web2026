'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import { ArrowRight, Home, TrendingUp, Shield } from 'lucide-react'
import PropertyCard from '@/components/PropertyCard'
import InvestmentQuiz from '@/components/forms/InvestmentQuiz'
import BuySellQuiz from '@/components/forms/BuySellQuiz'
import { useQuery } from '@tanstack/react-query'
import { createClient } from '@/lib/supabase/client'

export default function HomePage() {
  const supabase = createClient()

  const { data: featuredProperties } = useQuery({
    queryKey: ['featured-properties'],
    queryFn: async () => {
      const { data } = await supabase
        .from('properties')
        .select('*')
        .eq('published', true)
        .eq('status', 'aktivní')
        .order('created_at', { ascending: false })
        .limit(6)
      return data || []
    },
  })

  const reasons = [
    {
      icon: Home,
      title: 'Lokální znalost',
      text: 'Brno znám jako své boty, každou čtvrť mám v malíku.',
    },
    {
      icon: TrendingUp,
      title: 'Moderní marketing',
      text: 'Profesionální fotky, videa, dron, AI -- vaše nemovitost zazáří.',
    },
    {
      icon: Shield,
      title: 'Finanční zázemí',
      text: 'Díky partnerství s Ofis a.s. zajistím výhodné financování.',
    },
  ]

  return (
    <div>
      {/* Hero sekce */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-black/50 z-10" />
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover"
          poster="https://picsum.photos/seed/brno/1920/1080"
        >
          <source src="/videos/hero-bg.mp4" type="video/mp4" />
          <img src="https://picsum.photos/seed/brno/1920/1080" alt="" className="absolute inset-0 w-full h-full object-cover" />
        </video>
        <div className="relative z-20 max-w-7xl mx-auto px-4 text-center text-white">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-bold mb-6"
          >
            Reality, které dávají <span className="text-primary-400">smysl</span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl md:text-2xl mb-8 text-slate-200"
          >
            Exkluzivní prodej nemovitostí s podporou finanční skupiny Ofis a.s.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Link
              href="/nemovitosti"
              className="bg-primary-600 text-white px-8 py-4 rounded-xl font-medium hover:bg-primary-700 transition-colors"
            >
              Prohlédnout nemovitosti
            </Link>
            <Link
              href="/odhad"
              className="bg-white/10 backdrop-blur-sm text-white px-8 py-4 rounded-xl font-medium hover:bg-white/20 border border-white/20 transition-colors"
            >
              Odhadnout cenu
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Vybrané nemovitosti */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Vybrané nemovitosti</h2>
              <p className="text-lg text-slate-600">Nejnovější přírůstky v mé nabídce.</p>
            </div>
            <Link href="/nemovitosti" className="hidden md:flex items-center text-primary-600 hover:text-primary-700">
              Všechny nabídky <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredProperties?.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        </div>
      </section>

      {/* Proč prodávat se mnou */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">Proč prodávat se mnou?</h2>
          <div className="grid md:grid-cols-3 gap-12">
            {reasons.map((reason, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-20 h-20 bg-primary-100 rounded-3xl flex items-center justify-center mx-auto mb-6">
                  <reason.icon className="w-10 h-10 text-primary-600" />
                </div>
                <h3 className="text-xl font-semibold mb-3">{reason.title}</h3>
                <p className="text-slate-600">{reason.text}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Investiční kvíz */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="bg-primary-50 rounded-3xl p-8 md:p-12">
            <h2 className="text-3xl font-bold mb-8">Máte zájem o investici?</h2>
            <InvestmentQuiz />
          </div>
        </div>
      </section>

      {/* Koupě / prodej kvíz */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-sm">
            <h2 className="text-3xl font-bold mb-8">Chcete prodat nebo koupit?</h2>
            <BuySellQuiz />
          </div>
        </div>
      </section>
    </div>
  )
}
