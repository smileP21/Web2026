'use client'

import { useEffect } from 'react'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'

export default function ContactMap() {
  useEffect(() => {
    const mapElement = document.getElementById('contact-map')
    if (!mapElement) return

    const map = L.map('contact-map').setView([49.195, 16.606], 12) // Brno

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 19,
    }).addTo(map)

    // Přidání markeru na Brno
    L.marker([49.195, 16.606])
      .bindPopup('<b>Petr Šilhavý Reality</b><br>Brno, Česká republika')
      .addTo(map)
      .openPopup()

    return () => {
      map.remove()
    }
  }, [])

  return <div id="contact-map" className="w-full h-full" />
}
