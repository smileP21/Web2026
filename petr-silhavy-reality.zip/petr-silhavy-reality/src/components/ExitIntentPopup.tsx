'use client'

import { useState, useEffect } from 'react'
import { X } from 'lucide-react'

export default function ExitIntentPopup() {
  const [isOpen, setIsOpen] = useState(false)

  useEffect(() => {
    const handleMouseLeave = () => {
      setIsOpen(true)
    }

    document.addEventListener('mouseleave', handleMouseLeave)

    return () => {
      document.removeEventListener('mouseleave', handleMouseLeave)
    }
  }, [])

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl p-8 max-w-md relative">
        <button
          onClick={() => setIsOpen(false)}
          className="absolute top-4 right-4 text-slate-500 hover:text-slate-700"
        >
          <X className="w-6 h-6" />
        </button>

        <h2 className="text-2xl font-bold mb-4">Chce zbytečně odejít?</h2>
        <p className="text-slate-600 mb-6">
          Měl bych pro vás správnou nemovitost. Nechte mi svůj email a já se vám ozvu s nejlepšími nabídkami.
        </p>

        <form
          onSubmit={(e) => {
            e.preventDefault()
            setIsOpen(false)
          }}
          className="space-y-4"
        >
          <input type="email" placeholder="Váš email" required className="w-full p-3 border rounded-xl" />
          <button type="submit" className="w-full bg-primary-600 text-white py-3 rounded-xl font-medium">
            Poslat mi nabídky
          </button>
        </form>
      </div>
    </div>
  )
}
