import Link from 'next/link'
import { Mail, Phone, MapPin } from 'lucide-react'

export default function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="bg-slate-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-xl font-bold mb-4">Reality</h3>
            <p className="text-slate-300">Profesionální realitní služby v Brně</p>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Odkazy</h4>
            <div className="space-y-2 text-slate-300">
              <Link href="/nemovitosti" className="hover:text-white">
                Nemovitosti
              </Link>
              <Link href="/investice" className="hover:text-white block">
                Investice
              </Link>
              <Link href="/o-mne" className="hover:text-white block">
                O mně
              </Link>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Kontakt</h4>
            <div className="space-y-3 text-slate-300">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4" />
                <a href="tel:+420777449857">+420 777 449 857</a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                <a href="mailto:Silhavypetr.reality@gmail.com">Email</a>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Finanční partner</h4>
            <p className="text-slate-300 text-sm">Ofis a.s.</p>
          </div>
        </div>

        <div className="border-t border-slate-700 pt-8 text-center text-slate-400">
          <p>&copy; {year} Petr Šilhavý Reality. Všechna práva vyhrazena.</p>
        </div>
      </div>
    </footer>
  )
}
