'use client'

import Link from 'next/link'
import { useState } from 'react'
import { Menu, X } from 'lucide-react'

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <nav className="bg-white shadow-sm sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold text-primary-600">
          Reality
        </Link>

        {/* Desktop menu */}
        <div className="hidden md:flex gap-8">
          <Link href="/nemovitosti" className="hover:text-primary-600 transition">
            Nemovitosti
          </Link>
          <Link href="/investice" className="hover:text-primary-600 transition">
            Investice
          </Link>
          <Link href="/o-mne" className="hover:text-primary-600 transition">
            O mně
          </Link>
          <Link href="/kontakt" className="hover:text-primary-600 transition">
            Kontakt
          </Link>
        </div>

        {/* Mobile menu button */}
        <button onClick={() => setIsOpen(!isOpen)} className="md:hidden">
          {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-slate-50 p-4 flex flex-col gap-4">
          <Link href="/nemovitosti" className="hover:text-primary-600">
            Nemovitosti
          </Link>
          <Link href="/investice" className="hover:text-primary-600">
            Investice
          </Link>
          <Link href="/o-mne" className="hover:text-primary-600">
            O mně
          </Link>
          <Link href="/kontakt" className="hover:text-primary-600">
            Kontakt
          </Link>
        </div>
      )}
    </nav>
  )
}
