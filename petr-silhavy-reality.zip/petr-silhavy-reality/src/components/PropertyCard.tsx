import Link from 'next/link'
import Image from 'next/image'
import { MapPin, Home, Maximize } from 'lucide-react'
import { formatPrice } from '@/lib/utils'

interface Property {
  id: string
  title: string
  location: string
  price: number | null
  type: string
  size_sqm: number | null
  images?: string[]
}

export default function PropertyCard({ property }: { property: Property }) {
  const imageUrl = property.images?.[0] || 'https://picsum.photos/400/300'

  return (
    <Link href={`/nemovitosti/${property.id}`}>
      <div className="bg-white rounded-2xl overflow-hidden hover:shadow-xl transition-shadow cursor-pointer group">
        <div className="relative h-64 overflow-hidden">
          <Image
            src={imageUrl}
            alt={property.title}
            fill
            className="object-cover group-hover:scale-105 transition-transform"
          />
          <div className="absolute top-4 right-4 bg-primary-600 text-white px-3 py-1 rounded-full text-sm font-medium">
            {property.type}
          </div>
        </div>

        <div className="p-6">
          <h3 className="text-xl font-bold mb-2">{property.title}</h3>

          <div className="flex items-center text-slate-600 mb-4">
            <MapPin className="w-4 h-4 mr-1" /> {property.location}
          </div>

          <div className="text-2xl font-bold text-primary-600 mb-4">
            {property.price ? formatPrice(property.price) : 'Cena na vyžádání'}
          </div>

          <div className="flex gap-4 text-sm text-slate-600">
            <div className="flex items-center">
              <Home className="w-4 h-4 mr-1" /> {property.type}
            </div>
            {property.size_sqm && (
              <div className="flex items-center">
                <Maximize className="w-4 h-4 mr-1" /> {property.size_sqm} m²
              </div>
            )}
          </div>
        </div>
      </div>
    </Link>
  )
}
