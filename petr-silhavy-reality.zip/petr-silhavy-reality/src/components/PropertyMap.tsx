'use client'

import { useEffect } from 'react'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'

interface Property {
  id: string
  latitude: number | null
  longitude: number | null
  title: string
}

export default function PropertyMap({
  properties,
  center = [49.195, 16.606], // Brno
}: {
  properties: Property[]
  center?: [number, number]
}) {
  useEffect(() => {
    const mapElement = document.getElementById('map')
    if (!mapElement) return

    const map = L.map('map').setView(center, 13)

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 19,
    }).addTo(map)

    properties.forEach((property) => {
      if (property.latitude && property.longitude) {
        L.marker([property.latitude, property.longitude])
          .bindPopup(`<b>${property.title}</b>`)
          .addTo(map)
      }
    })

    return () => {
      map.remove()
    }
  }, [properties, center])

  return <div id="map" className="w-full h-full" />
}
