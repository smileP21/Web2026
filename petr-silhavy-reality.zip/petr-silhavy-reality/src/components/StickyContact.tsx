'use client'

import Link from 'next/link'
import { MessageCircle, Phone } from 'lucide-react'

export default function StickyContact() {
  return (
    <div className="fixed bottom-6 right-6 flex flex-col gap-3 z-40 md:hidden">
      <a
        href="tel:+420777449857"
        className="bg-primary-600 text-white p-4 rounded-full shadow-lg hover:bg-primary-700 transition-all hover:scale-110"
      >
        <Phone className="w-6 h-6" />
      </a>
      <Link
        href="/kontakt"
        className="bg-primary-600 text-white p-4 rounded-full shadow-lg hover:bg-primary-700 transition-all hover:scale-110"
      >
        <MessageCircle className="w-6 h-6" />
      </Link>
    </div>
  )
}
