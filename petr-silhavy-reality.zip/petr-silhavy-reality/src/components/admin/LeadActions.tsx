'use client'

import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

export default function LeadActions({ leadId, currentStatus }: { leadId: string; currentStatus: string }) {
  const router = useRouter()
  const supabase = createClient()

  const updateStatus = async (status: string) => {
    await supabase.from('leads').update({ status }).eq('id', leadId)
    router.refresh()
  }

  return (
    <select
      value={currentStatus}
      onChange={(e) => updateStatus(e.target.value)}
      className="border rounded-xl p-2"
    >
      <option value="Nová">Nová</option>
      <option value="Kontaktována">Kontaktována</option>
      <option value="Schůzka domluvena">Schůzka domluvena</option>
      <option value="Uzavřeno">Uzavřeno</option>
    </select>
  )
}
