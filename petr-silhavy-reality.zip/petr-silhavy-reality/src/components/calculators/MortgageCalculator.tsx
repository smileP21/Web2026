'use client'

import { useState } from 'react'
import { formatPrice } from '@/lib/utils'

export default function MortgageCalculator() {
  const [price, setPrice] = useState(3000000)
  const [downPayment, setDownPayment] = useState(600000)
  const [years, setYears] = useState(20)
  const [rate, setRate] = useState(3.5)

  const loanAmount = price - downPayment
  const monthlyRate = rate / 100 / 12
  const numberOfPayments = years * 12

  const monthlyPayment =
    (loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments))) /
    (Math.pow(1 + monthlyRate, numberOfPayments) - 1)

  const downPaymentPercent = ((downPayment / price) * 100).toFixed(0)

  return (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium mb-2">
          Cena nemovitosti: {formatPrice(price)}
        </label>
        <input
          type="range"
          min={100000}
          max={10000000}
          step={100000}
          value={price}
          onChange={(e) => setPrice(Number(e.target.value))}
          className="w-full"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">
          Vlastní vklad: {formatPrice(downPayment)} ({downPaymentPercent}%)
        </label>
        <input
          type="range"
          min={0}
          max={price}
          step={100000}
          value={downPayment}
          onChange={(e) => setDownPayment(Number(e.target.value))}
          className="w-full"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Doba splácení: {years} let</label>
        <input
          type="range"
          min={5}
          max={40}
          step={1}
          value={years}
          onChange={(e) => setYears(Number(e.target.value))}
          className="w-full"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Úroková sazba: {rate}%</label>
        <input
          type="range"
          min={1}
          max={8}
          step={0.1}
          value={rate}
          onChange={(e) => setRate(Number(e.target.value))}
          className="w-full"
        />
      </div>

      <div className="bg-primary-50 p-6 rounded-2xl mt-8">
        <div className="space-y-2">
          <div className="flex justify-between">
            <span>Výše úvěru:</span>
            <span className="font-bold">{formatPrice(loanAmount)}</span>
          </div>
          <div className="flex justify-between">
            <span>Měsíční splátka:</span>
            <span className="text-2xl font-bold text-primary-600">{formatPrice(monthlyPayment)}</span>
          </div>
          <div className="flex justify-between pt-4 border-t text-sm">
            <span>Celkem za dobu splácení:</span>
            <span>{formatPrice(monthlyPayment * numberOfPayments)}</span>
          </div>
        </div>
      </div>
    </div>
  )
}
