'use client'

import { useState } from 'react'
import { formatPrice } from '@/lib/utils'

export default function RoiCalculator() {
  const [investmentAmount, setInvestmentAmount] = useState(3000000)
  const [monthlyRent, setMonthlyRent] = useState(15000)
  const [yearsToCalculate, setYearsToCalculate] = useState(10)
  const [annualAppreciation, setAnnualAppreciation] = useState(3)

  const monthlyIncome = monthlyRent * 12
  const totalIncomeInYears = monthlyIncome * yearsToCalculate

  // Cena nemovitosti po X let s apreciací
  const futurePrice = investmentAmount * Math.pow(1 + annualAppreciation / 100, yearsToCalculate)
  const priceAppreciation = futurePrice - investmentAmount

  const totalReturn = totalIncomeInYears + priceAppreciation
  const roi = ((totalReturn / investmentAmount) * 100).toFixed(1)
  const annualRoi = (roi / yearsToCalculate).toFixed(1)

  return (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium mb-2">
          Investiční částka: {formatPrice(investmentAmount)}
        </label>
        <input
          type="range"
          min={500000}
          max={10000000}
          step={100000}
          value={investmentAmount}
          onChange={(e) => setInvestmentAmount(Number(e.target.value))}
          className="w-full"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">
          Měsíční pronájem: {formatPrice(monthlyRent)}
        </label>
        <input
          type="range"
          min={5000}
          max={100000}
          step={1000}
          value={monthlyRent}
          onChange={(e) => setMonthlyRent(Number(e.target.value))}
          className="w-full"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Doba investice: {yearsToCalculate} let</label>
        <input
          type="range"
          min={1}
          max={30}
          step={1}
          value={yearsToCalculate}
          onChange={(e) => setYearsToCalculate(Number(e.target.value))}
          className="w-full"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">
          Roční apreciace: {annualAppreciation}%
        </label>
        <input
          type="range"
          min={0}
          max={10}
          step={0.5}
          value={annualAppreciation}
          onChange={(e) => setAnnualAppreciation(Number(e.target.value))}
          className="w-full"
        />
      </div>

      <div className="bg-primary-50 p-6 rounded-2xl mt-8 space-y-3">
        <div className="flex justify-between">
          <span>Celkový pronájem:</span>
          <span className="font-bold">{formatPrice(totalIncomeInYears)}</span>
        </div>
        <div className="flex justify-between">
          <span>Apreciace nemovitosti:</span>
          <span className="font-bold">{formatPrice(priceAppreciation)}</span>
        </div>
        <div className="flex justify-between pt-4 border-t">
          <span>Celkový výnos:</span>
          <span className="text-xl font-bold text-primary-600">{formatPrice(totalReturn)}</span>
        </div>
        <div className="flex justify-between pt-2 border-t text-sm">
          <span>Celkový ROI:</span>
          <span className="font-bold">{roi}%</span>
        </div>
        <div className="flex justify-between text-sm">
          <span>Roční ROI:</span>
          <span className="font-bold">{annualRoi}%</span>
        </div>
      </div>
    </div>
  )
}
