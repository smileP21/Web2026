'use client'

import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'

export default function InvestmentQuiz() {
  const [currentStep, setCurrentStep] = useState(0)
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    budget: '',
    investmentType: '',
  })
  const [submitted, setSubmitted] = useState(false)

  const supabase = createClient()

  const steps = [
    {
      title: 'Jaké je vaše jméno?',
      field: 'name',
      type: 'text',
    },
    {
      title: 'Váš email?',
      field: 'email',
      type: 'email',
    },
    {
      title: 'Váš telefon?',
      field: 'phone',
      type: 'tel',
    },
    {
      title: 'Jaký je váš rozpočet?',
      field: 'budget',
      type: 'select',
      options: ['Do 1M Kč', '1-3M Kč', '3-5M Kč', 'Více než 5M Kč'],
    },
  ]

  const handleChange = (e: any) => {
    setFormData({
      ...formData,
      [steps[currentStep].field]: e.target.value,
    })
  }

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      handleSubmit()
    }
  }

  const handleSubmit = async () => {
    await supabase.from('leads').insert([
      {
        type: 'investice',
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        data: { budget: formData.budget },
        status: 'Nová',
      },
    ])

    setSubmitted(true)
  }

  if (submitted) {
    return (
      <div className="text-center p-8 bg-green-50 rounded-2xl">
        <p className="text-green-800 text-lg">Děkuji za váš zájem! Brzy se vám ozvu.</p>
      </div>
    )
  }

  const step = steps[currentStep]

  return (
    <div>
      <h3 className="text-2xl font-bold mb-6">{step.title}</h3>

      {step.type === 'select' ? (
        <div className="grid grid-cols-2 gap-4 mb-6">
          {step.options?.map((option) => (
            <button
              key={option}
              onClick={() => setFormData({ ...formData, [step.field]: option })}
              className={`p-4 rounded-xl border-2 transition ${
                formData[step.field as keyof typeof formData] === option
                  ? 'border-primary-600 bg-primary-50'
                  : 'border-slate-200 hover:border-primary-600'
              }`}
            >
              {option}
            </button>
          ))}
        </div>
      ) : (
        <input
          type={step.type}
          placeholder={step.title}
          value={formData[step.field as keyof typeof formData]}
          onChange={handleChange}
          className="w-full p-4 border rounded-xl mb-6"
        />
      )}

      <button
        onClick={handleNext}
        className="w-full bg-primary-600 text-white py-3 rounded-xl font-medium hover:bg-primary-700"
      >
        {currentStep === steps.length - 1 ? 'Odeslat' : 'Další'}
      </button>
    </div>
  )
}
