'use client'

import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'

const schema = z.object({
  name: z.string().min(1, 'Jméno je povinné'),
  email: z.string().email('Neplatný email'),
  phone: z.string().min(9, 'Telefon je povinný'),
  message: z.string().optional(),
})

type FormData = z.infer<typeof schema>

export default function PropertyContactForm({ propertyId }: { propertyId: string }) {
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')
  const supabase = createClient()

  const { register, handleSubmit, formState: { errors }, reset } = useForm<FormData>({
    resolver: zodResolver(schema),
  })

  const onSubmit = async (data: FormData) => {
    setStatus('loading')

    const { error } = await supabase.from('leads').insert([
      {
        type: 'prohlídka',
        property_id: propertyId,
        ...data,
        status: 'Nová',
      },
    ])

    if (error) {
      setStatus('error')
    } else {
      setStatus('success')
      reset()
      setTimeout(() => setStatus('idle'), 3000)
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      {status === 'success' && (
        <div className="bg-green-50 p-4 rounded-xl text-green-800">
          Děkuji za váš zájem! Brzy se vám ozvu.
        </div>
      )}

      <div>
        <input
          {...register('name')}
          placeholder="Jméno a příjmení"
          className="w-full p-3 border rounded-xl"
        />
        {errors.name && <p className="text-red-600 text-sm mt-1">{errors.name.message}</p>}
      </div>

      <div>
        <input
          {...register('email')}
          type="email"
          placeholder="Email"
          className="w-full p-3 border rounded-xl"
        />
        {errors.email && <p className="text-red-600 text-sm mt-1">{errors.email.message}</p>}
      </div>

      <div>
        <input
          {...register('phone')}
          placeholder="Telefon"
          className="w-full p-3 border rounded-xl"
        />
        {errors.phone && <p className="text-red-600 text-sm mt-1">{errors.phone.message}</p>}
      </div>

      <div>
        <textarea
          {...register('message')}
          rows={3}
          placeholder="Zpráva (volitelné)"
          className="w-full p-3 border rounded-xl"
        />
      </div>

      <button
        type="submit"
        disabled={status === 'loading'}
        className="w-full bg-primary-600 text-white py-3 rounded-xl font-medium hover:bg-primary-700 transition-colors disabled:opacity-50"
      >
        {status === 'loading' ? 'Odesílání...' : 'Chci vidět nemovitost'}
      </button>
    </form>
  )
}
