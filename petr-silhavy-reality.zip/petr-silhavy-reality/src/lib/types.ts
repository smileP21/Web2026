export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      properties: {
        Row: {
          id: string
          created_at: string
          title: string
          slug: string
          price: number | null
          location: string
          address: string | null
          type: string
          size_sqm: number | null
          bedrooms: number | null
          condition: string | null
          description: string | null
          images: string[]
          latitude: number | null
          longitude: number | null
          external_link: string | null
          status: string
          published: boolean
        }
        Insert: {}
        Update: {}
      }
      leads: {
        Row: {
          id: string
          created_at: string
          type: string
          name: string
          email: string
          phone: string
          message: string | null
          property_id: string | null
          data: Json | null
          status: string
        }
        Insert: {}
        Update: {}
      }
      blog_posts: {
        Row: {
          id: string
          created_at: string
          title: string
          slug: string
          excerpt: string | null
          content: string | null
          image: string | null
          category: string | null
          published: boolean
          published_at: string | null
        }
        Insert: {}
        Update: {}
      }
      settings: {
        Row: {
          key: string
          value: string
          updated_at: string
        }
        Insert: {}
        Update: {}
      }
    }
    Views: {}
    Functions: {}
    Enums: {}
  }
}
